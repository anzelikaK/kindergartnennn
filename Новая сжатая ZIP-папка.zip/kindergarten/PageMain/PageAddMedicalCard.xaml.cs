﻿using kindergarten.ApplicationDate;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kindergarten.PageMain
{

    public partial class PageAddMedicalCard : Page
    {
        private MedicalCard _currentMedicalCard = new MedicalCard();
        public PageAddMedicalCard(MedicalCard selectedMedicalCard)
        {
            InitializeComponent();
            if(selectedMedicalCard != null)
                _currentMedicalCard = selectedMedicalCard;
            DataContext = _currentMedicalCard;
            cmbChild.ItemsSource = kindergartenEntities.GetContext().Child.ToList();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();

            // Проверка обязательных полей
            if (_currentMedicalCard.DateCreation == null)
                errors.AppendLine("Укажите дату");

            if (string.IsNullOrWhiteSpace(_currentMedicalCard.GeneralInformation))
                errors.AppendLine("Укажите информацию");

            if (_currentMedicalCard.idChild == null || _currentMedicalCard.idChild == 0)
                errors.AppendLine("Выберите ребенка");

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                var context = kindergartenEntities.GetContext();

                // Проверяем, есть ли уже медкарта у этого ребенка
                if (_currentMedicalCard.IdMedicalCard == 0) // Только для новых карт
                {
                    bool hasExistingCard = context.MedicalCard
                        .Any(m => m.idChild == _currentMedicalCard.idChild);

                    if (hasExistingCard)
                    {
                        MessageBox.Show("У этого ребенка уже есть медицинская карта!",
                                       "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                }

                // Сохраняем данные
                if (_currentMedicalCard.IdMedicalCard == 0)
                    context.MedicalCard.Add(_currentMedicalCard);

                context.SaveChanges();
                MessageBox.Show("Данные сохранены!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                AppFrame.SecondFrame.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}\n\n{ex.InnerException?.Message}",
                               "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.SecondFrame.Navigate(new PageMedicalCard(null));
        }

     

        
       
    }
}
