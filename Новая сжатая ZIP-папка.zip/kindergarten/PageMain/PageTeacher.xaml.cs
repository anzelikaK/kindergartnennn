﻿using kindergarten.ApplicationDate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kindergarten.PageMain
{
    
    public partial class PageTeacher : Page
    {
        public PageTeacher()
        {
            InitializeComponent();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var selectedTeacher = DtGridTeacher.SelectedItem as Teacher;
            if (selectedTeacher == null)
            {
                MessageBox.Show("Выберите воспитателя!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            AppFrame.SecondFrame.Navigate(new PageEditTeacher(selectedTeacher));
        }

        private void btnDel_Click(object sender, RoutedEventArgs e)
        {
            if (DtGridTeacher.SelectedItem == null)
            {
                MessageBox.Show("Выберите воспитателя для удаления!", "Ошибка",
                               MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var result = MessageBox.Show("Удалить выбранного воспитателя?", "Подтверждение",
                                        MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes) return;

            try
            {
                Teacher selectedTeacher = DtGridTeacher.SelectedItem as Teacher;
                var context = kindergartenEntities.GetContext();

                // Получаем список групп этого учителя
                var teacherGroups = context.Group
                                        .Where(g => g.idTeacher == selectedTeacher.idTeacher)
                                        .Select(g => g.GroupName)
                                        .ToList();

                if (teacherGroups.Any())
                {
                    // Создаем нумерованный список
                    var numberedGroups = teacherGroups.Select((name, index) => $"{index + 1}) {name}");
                    string groupsList = string.Join("\n", numberedGroups);

                    MessageBox.Show($"Невозможно удалить воспитателя, так как у него есть группы:\n" +
                                   $"{groupsList};\n\n" +
                                   $"Сначала переназначьте воспитателя группы или удалите группы.",
                                   "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                context.Teacher.Remove(selectedTeacher);
                context.SaveChanges();

                DtGridTeacher.ItemsSource = context.Teacher.ToList();
                MessageBox.Show("Воспитатель удален!", "Успех",
                               MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удаления: {ex.Message}\n\n" +
                              $"Подробности: {ex.InnerException?.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.SecondFrame.Navigate(new PageEditTeacher(null));
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if(Visibility == Visibility.Visible)
            {
                kindergartenEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(x => x.Reload());
                DtGridTeacher.ItemsSource = kindergartenEntities.GetContext().Teacher.ToList();
            }
        }
    }
}
