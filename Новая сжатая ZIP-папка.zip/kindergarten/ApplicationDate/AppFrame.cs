﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace kindergarten.ApplicationDate
{
    internal class AppFrame
    {
        public static Frame FrameMain;
        public static Frame SecondFrame;

    }
}
